Whatnot Finder v9.1 Repair
Replace index.html and service-worker.js in repository root, and create or replace version.json. Upload all three together and commit. Other included icons are optional WT logo replacements. Do not upload purchase CSV or backups. Back up edits before changing app. Do not uninstall.
